import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { supabase } from '../lib/supabase';
import type { Admin, Voter } from '../types';

const JWT_SECRET = 'your-jwt-secret-key'; // In production, use environment variable

export interface LoginResponse {
  user: Admin | Voter;
  token: string;
  userType: 'admin' | 'voter';
}

export const loginAdmin = async (username: string, password: string): Promise<LoginResponse> => {
  const { data: admin, error } = await supabase
    .from('admins')
    .select('*')
    .eq('username', username)
    .single();

  if (error || !admin) {
    throw new Error('Invalid credentials');
  }

  const isValidPassword = await bcrypt.compare(password, admin.password_hash);
  if (!isValidPassword) {
    throw new Error('Invalid credentials');
  }

  const token = jwt.sign(
    { id: admin.id, type: 'admin' },
    JWT_SECRET,
    { expiresIn: '24h' }
  );

  return {
    user: admin,
    token,
    userType: 'admin'
  };
};

export const loginVoter = async (nisn: string): Promise<LoginResponse> => {
  const { data: voter, error } = await supabase
    .from('voters')
    .select('*')
    .eq('nisn', nisn)
    .single();

  if (error || !voter) {
    throw new Error('NISN tidak ditemukan');
  }

  const token = jwt.sign(
    { id: voter.id, type: 'voter' },
    JWT_SECRET,
    { expiresIn: '24h' }
  );

  return {
    user: voter,
    token,
    userType: 'voter'
  };
};

export const verifyToken = (token: string) => {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    throw new Error('Invalid token');
  }
};