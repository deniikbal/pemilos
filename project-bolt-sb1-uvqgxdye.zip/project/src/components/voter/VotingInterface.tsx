import React, { useState, useEffect } from 'react';
import { User, CheckCircle, Award } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { getCandidates, submitVote } from '../../services/api';
import type { Candidate, Voter } from '../../types';

const VotingInterface: React.FC = () => {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [voting, setVoting] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<string | null>(null);
  const [voted, setVoted] = useState(false);
  
  const { user } = useAuth();
  const voter = user as Voter;

  useEffect(() => {
    loadCandidates();
    
    // Check if voter already voted
    if (voter?.has_voted) {
      setVoted(true);
    }
  }, [voter]);

  const loadCandidates = async () => {
    try {
      setLoading(true);
      const data = await getCandidates();
      setCandidates(data);
    } catch (error) {
      console.error('Failed to load candidates:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVote = async () => {
    if (!selectedCandidate || !voter) return;

    if (!confirm('Apakah Anda yakin dengan pilihan ini? Pilihan tidak dapat diubah setelah dikonfirmasi.')) {
      return;
    }

    try {
      setVoting(true);
      await submitVote(voter.id, selectedCandidate);
      setVoted(true);
    } catch (error: any) {
      alert('Gagal submit vote: ' + error.message);
    } finally {
      setVoting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (voted) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center max-w-md mx-auto">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Terima Kasih Sudah Memilih!
          </h2>
          
          <p className="text-gray-600 mb-6">
            Suara Anda telah berhasil tercatat dalam sistem. Terima kasih atas partisipasi Anda dalam pemilihan Ketua OSIS SMAN 1 Bantarujeg.
          </p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>Catatan:</strong> Hasil pemilihan akan diumumkan setelah periode voting berakhir.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Pemilihan Ketua OSIS
        </h1>
        <p className="text-gray-600 mb-4">
          Selamat datang, <strong>{voter?.nama}</strong> dari kelas <strong>{voter?.kelas}</strong>
        </p>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 max-w-2xl mx-auto">
          <p className="text-sm text-yellow-800">
            <strong>Penting:</strong> Anda hanya dapat memilih sekali. Pilihan tidak dapat diubah setelah dikonfirmasi.
          </p>
        </div>
      </div>

      {/* Candidates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {candidates.map((candidate) => (
          <div 
            key={candidate.id}
            className={`bg-white rounded-xl shadow-sm border-2 transition-all cursor-pointer hover:shadow-md ${
              selectedCandidate === candidate.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
            onClick={() => setSelectedCandidate(candidate.id)}
          >
            <div className="aspect-w-16 aspect-h-12">
              {candidate.foto_url ? (
                <img
                  src={candidate.foto_url}
                  alt={candidate.nama}
                  className="w-full h-48 object-cover rounded-t-xl"
                />
              ) : (
                <div className="w-full h-48 bg-gray-100 flex items-center justify-center rounded-t-xl">
                  <User className="h-16 w-16 text-gray-400" />
                </div>
              )}
            </div>
            
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-gray-900">
                  {candidate.nama}
                </h3>
                {selectedCandidate === candidate.id && (
                  <CheckCircle className="h-6 w-6 text-blue-600" />
                )}
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center">
                    <Award className="h-4 w-4 mr-1" />
                    Visi
                  </h4>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {candidate.visi}
                  </p>
                </div>
                
                <div>
                  <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center">
                    <Award className="h-4 w-4 mr-1" />
                    Misi
                  </h4>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {candidate.misi}
                  </p>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-200">
                <button
                  onClick={() => setSelectedCandidate(candidate.id)}
                  className={`w-full py-2 px-4 rounded-lg font-medium transition-colors ${
                    selectedCandidate === candidate.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {selectedCandidate === candidate.id ? 'Dipilih' : 'Pilih Kandidat Ini'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {candidates.length === 0 && (
        <div className="text-center py-12">
          <User className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Belum ada kandidat</h3>
          <p className="mt-1 text-sm text-gray-500">Silakan tunggu admin menambahkan kandidat</p>
        </div>
      )}

      {/* Submit Button */}
      {selectedCandidate && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-10">
          <button
            onClick={handleVote}
            disabled={voting}
            className="bg-green-600 text-white px-8 py-3 rounded-full shadow-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium text-lg"
          >
            {voting ? 'Menyimpan...' : 'Konfirmasi Pilihan'}
          </button>
        </div>
      )}
    </div>
  );
};

export default VotingInterface;